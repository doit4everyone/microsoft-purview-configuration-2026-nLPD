-- ============================================================
-- BASE DE DONNEES : axonix_db
-- Description     : Base de donnees fictive Axonix SA
-- Azure SQL Server : axonix-sql-srv.database.windows.net
-- Creee le         : Janvier 2025
-- ============================================================

-- Supprimer si existe
DROP TABLE IF EXISTS dbo.Tickets;
DROP TABLE IF EXISTS dbo.Factures;
DROP TABLE IF EXISTS dbo.Projets;
DROP TABLE IF EXISTS dbo.Employes;
DROP TABLE IF EXISTS dbo.Clients;

-- ── TABLE CLIENTS ─────────────────────────────────────────
CREATE TABLE dbo.Clients (
    ClientID        INT IDENTITY(1,1) PRIMARY KEY,
    RaisonSociale   NVARCHAR(100) NOT NULL,
    Secteur         NVARCHAR(50),
    Adresse         NVARCHAR(200),
    Ville           NVARCHAR(50),
    CodePostal      NVARCHAR(10),
    Telephone       NVARCHAR(20),
    Email           NVARCHAR(100),
    ContactPrincipal NVARCHAR(100),
    NiveauContrat   NVARCHAR(20),   -- BRONZE / SILVER / GOLD / PLATINUM
    DateDebut       DATE,
    ChiffreAffaires DECIMAL(12,2),
    Actif           BIT DEFAULT 1
);

INSERT INTO dbo.Clients VALUES
('Baumont Industries SA','Industrie','Zone Industrielle Nord','Saint-Sulpice','1025','+41 21 694 33 00','it@baumont.ch','Marc Duperrex','GOLD','2014-03-01',142000,1),
('Clinique du Lac SA','Sante','Chemin des Alpes 12','Montreux','1820','+41 21 966 22 00','info@clinique-du-lac.ch','Dr. Valerie Ansermet','PLATINUM','2016-07-01',98000,1),
('Etude Rochat & Associes','Juridique','Rue du Midi 8','Vevey','1800','+41 21 922 44 00','p.rochat@etude-rochat.ch','Philippe Rochat','SILVER','2018-01-01',34800,1),
('Commune de Rolle','Administration publique','Place du Chateau 1','Rolle','1180','+41 21 825 17 00','informatique@rolle.ch','Jean-Luc Meylan','SILVER','2019-04-01',28500,1),
('FinGroup SA','Finance','Rue de Rive 4','Geneve','1204','+41 22 310 55 00','it@fingroup.ch','Patricia Coen','PLATINUM','2020-02-01',87000,1),
('EcoLogis Romande','Immobilier','Avenue de la Gare 22','Lausanne','1003','+41 21 320 40 00','admin@ecologis.ch','Bernard Roulet','SILVER','2021-06-01',31200,1),
('Transport Riviera SA','Transport','Route de Berne 45','Vevey','1800','+41 21 921 66 00','it@transport-riviera.ch','Sandra Metraux','GOLD','2022-01-01',54000,1),
('Hotel du Parc SA','Hotellerie','Avenue de la Gare 5','Morges','1110','+41 21 804 33 00','direction@hotel-du-parc.ch','Francois Dutoit','BRONZE','2023-03-01',18600,1),
('Garage Mottas SA','Automobile','Route Cantonale 112','Gland','1196','+41 22 364 11 00','info@garage-mottas.ch','Robert Mottas','BRONZE','2025-01-01',2400,1);

-- ── TABLE EMPLOYES ────────────────────────────────────────
CREATE TABLE dbo.Employes (
    EmployeID       INT IDENTITY(1,1) PRIMARY KEY,
    Prenom          NVARCHAR(50),
    Nom             NVARCHAR(50),
    Email           NVARCHAR(100),
    Poste           NVARCHAR(100),
    Departement     NVARCHAR(50),
    TauxActivite    DECIMAL(4,2),
    Salaire         DECIMAL(10,2),
    DateEntree      DATE,
    Actif           BIT DEFAULT 1
);

INSERT INTO dbo.Employes VALUES
('Laurent','Meier','l.meier@axonix.ch','CEO / Directeur general','Direction',1.00,185000,'2012-03-15',1),
('Sophie','Tanner','s.tanner@axonix.ch','CFO / Directrice financiere','Finance',1.00,145000,'2014-06-01',1),
('Remy','Blanc','r.blanc@axonix.ch','CTO / Directeur technique','IT',1.00,155000,'2012-03-15',1),
('Isabelle','Fontaine','i.fontaine@axonix.ch','Responsable RH','RH',0.80,78000,'2016-09-01',1),
('Kevin','Dubois','k.dubois@axonix.ch','Responsable commercial','Commercial',1.00,98000,'2018-01-15',1),
('Nicolas','Favre','n.favre@axonix.ch','Lead ingenieur systemes','IT',1.00,112000,'2013-02-01',1),
('Marie','Rochat','m.rochat@axonix.ch','Ingenieure Cloud Azure','IT',1.00,108000,'2020-04-01',1),
('Thomas','Gaillard','t.gaillard@axonix.ch','Ingenieur securite','IT',1.00,115000,'2019-09-01',1),
('Chloe','Burnand','c.burnand@axonix.ch','Developpeuse Python / IA','IT',1.00,95000,'2022-08-01',1),
('Pierre','Vaucher','p.vaucher@axonix.ch','Technicien support N2','IT',1.00,72000,'2017-03-01',1),
('Laure','Morel','l.morel@axonix.ch','Assistante de direction','Direction',0.80,62000,'2015-11-01',1),
('Jean-Paul','Rochefort','jp.rochefort@axonix.ch','Commercial senior','Commercial',1.00,92000,'2019-03-01',1);

-- ── TABLE PROJETS ─────────────────────────────────────────
CREATE TABLE dbo.Projets (
    ProjetID        INT IDENTITY(1,1) PRIMARY KEY,
    ClientID        INT FOREIGN KEY REFERENCES dbo.Clients(ClientID),
    Intitule        NVARCHAR(200),
    TypeProjet      NVARCHAR(50),
    Statut          NVARCHAR(20),   -- EN_COURS / LIVRE / ANNULE / EN_ATTENTE
    DateDebut       DATE,
    DateFinPrevue   DATE,
    DateFinReelle   DATE,
    BudgetHT        DECIMAL(12,2),
    FactureHT       DECIMAL(12,2),
    ChefProjet      INT FOREIGN KEY REFERENCES dbo.Employes(EmployeID)
);

INSERT INTO dbo.Projets VALUES
(1,'Migration serveurs vers Azure Hybrid','Migration Cloud','LIVRE','2024-01-15','2024-04-30','2024-04-22',42000,42000,6),
(2,'Audit securite et conformite LPD','Securite','LIVRE','2024-02-01','2024-03-31','2024-03-28',18500,18500,8),
(3,'Deploiement M365 + SharePoint','Microsoft 365','LIVRE','2024-03-01','2024-05-31','2024-06-10',24000,24000,7),
(4,'Contrat maintenance annuel 2024','Maintenance','LIVRE','2024-01-01','2024-12-31','2024-12-31',34800,34800,6),
(5,'Migration ERP Sage vers Azure SQL','Migration Cloud','EN_COURS','2025-02-01','2025-06-30',NULL,67000,20000,6),
(6,'Agent IA service technique interne','IA / Innovation','EN_COURS','2025-01-15','2025-07-31',NULL,0,0,9),
(7,'Reponse AO migration Azure Baumont','Avant-vente','EN_COURS','2025-04-01','2025-05-31',NULL,69000,0,5),
(8,'Audit penetration FinGroup SA','Securite','LIVRE','2024-11-01','2024-12-15','2024-12-12',28000,28000,8),
(9,'Power BI dashboard direction EcoLogis','BI / Reporting','LIVRE','2024-09-01','2024-10-31','2024-10-28',12500,12500,9),
(10,'Migration Exchange vers M365 Commune Rolle','Microsoft 365','LIVRE','2024-06-01','2024-08-31','2024-09-05',15000,15000,7);

-- ── TABLE TICKETS ─────────────────────────────────────────
CREATE TABLE dbo.Tickets (
    TicketID        INT IDENTITY(1,1) PRIMARY KEY,
    ClientID        INT FOREIGN KEY REFERENCES dbo.Clients(ClientID),
    Titre           NVARCHAR(200),
    Description     NVARCHAR(1000),
    Priorite        NVARCHAR(10),   -- P1/P2/P3/P4
    Statut          NVARCHAR(20),   -- OUVERT / EN_COURS / RESOLU / FERME
    DateOuverture   DATETIME,
    DateResolution  DATETIME,
    TechnicienID    INT FOREIGN KEY REFERENCES dbo.Employes(EmployeID),
    HeuresPassees   DECIMAL(5,2),
    Categorie       NVARCHAR(50)
);

INSERT INTO dbo.Tickets VALUES
(1,'Serveur DC1 inaccessible - production arretee','Le controleur de domaine principal ne repond plus depuis 14h32. Tous les utilisateurs sont impactes.','P1','FERME','2025-03-10 14:32:00','2025-03-10 16:45:00',6,2.25,'Infrastructure'),
(3,'Outlook ne se synchronise plus - 5 utilisateurs','Depuis la mise a jour Windows, 5 utilisateurs ont Outlook en mode hors connexion.','P3','FERME','2025-03-11 09:15:00','2025-03-11 11:30:00',10,2.25,'Microsoft 365'),
(2,'Alerte sauvegarde Azure Backup echouee','Job de sauvegarde des VMs echoue depuis 3 jours. Vault: axonix-backup-vault.','P3','FERME','2025-03-12 08:00:00','2025-03-12 14:20:00',6,6.33,'Sauvegarde'),
(5,'Tentatives connexion suspectes - alerte Sentinel','Microsoft Sentinel a detecte 47 tentatives de connexion depuis IP 185.220.x.x en 10 minutes.','P2','FERME','2025-03-13 03:22:00','2025-03-13 06:45:00',8,3.38,'Securite'),
(1,'Probleme imprimante salle de reunion','Imprimante HP LaserJet ne repond plus apres deplacement dans nouvelle salle.','P4','FERME','2025-03-14 10:00:00','2025-03-14 11:30:00',10,1.50,'Materiel'),
(4,'Acces SharePoint refuse apres changement poste','Utilisateur Jean Martin ne peut plus acceder au SharePoint depuis son nouveau PC.','P3','FERME','2025-03-14 14:00:00','2025-03-14 15:45:00',10,1.75,'Microsoft 365'),
(6,'Migration donnees OneDrive vers SharePoint equipe','Transfert de 450 Go de donnees utilisateur vers le nouveau site SharePoint equipe.','P4','EN_COURS','2025-03-15 09:00:00',NULL,7,3.00,'Microsoft 365'),
(2,'Certificat SSL expire - site intranet','Le certificat SSL du site intranet expire dans 7 jours. Renouvellement necessaire.','P3','EN_COURS','2025-03-15 11:00:00',NULL,8,1.00,'Securite'),
(3,'Nouveau collaborateur - setup poste','Preparation et configuration du poste de travail pour nouveau collaborateur RH.','P4','OUVERT','2025-03-17 09:00:00',NULL,10,0,'Support'),
(5,'Audit droits utilisateurs Entra ID','Revue trimestrielle des droits et acces dans Entra ID / groupes AD.','P3','OUVERT','2025-03-17 10:00:00',NULL,8,0,'Securite');

-- ── TABLE FACTURES ────────────────────────────────────────
CREATE TABLE dbo.Factures (
    FactureID       INT IDENTITY(1,1) PRIMARY KEY,
    ClientID        INT FOREIGN KEY REFERENCES dbo.Clients(ClientID),
    ProjetID        INT FOREIGN KEY REFERENCES dbo.Projets(ProjetID),
    NumeroFacture   NVARCHAR(20),
    DateFacture     DATE,
    DateEcheance    DATE,
    MontantHT       DECIMAL(12,2),
    TVA             DECIMAL(12,2),
    MontantTTC      DECIMAL(12,2),
    Statut          NVARCHAR(20),   -- PAYEE / EN_ATTENTE / EN_RETARD
    DatePaiement    DATE
);

INSERT INTO dbo.Factures VALUES
(1,1,'FAC-2025-001','2025-01-31','2025-03-02',3500,283.50,3783.50,'PAYEE','2025-02-28'),
(2,NULL,'FAC-2025-002','2025-01-31','2025-03-02',8166.67,661.50,8828.17,'PAYEE','2025-02-25'),
(3,4,'FAC-2025-003','2025-01-31','2025-03-02',2900,234.90,3134.90,'PAYEE','2025-03-01'),
(4,NULL,'FAC-2025-004','2025-01-31','2025-03-02',2375,192.38,2567.38,'PAYEE','2025-02-20'),
(5,NULL,'FAC-2025-005','2025-01-31','2025-03-02',7250,587.25,7837.25,'PAYEE','2025-03-05'),
(6,NULL,'FAC-2025-006','2025-01-31','2025-03-02',2600,210.60,2810.60,'PAYEE','2025-02-22'),
(7,NULL,'FAC-2025-007','2025-01-31','2025-03-02',4500,364.50,4864.50,'PAYEE','2025-03-10'),
(8,NULL,'FAC-2025-008','2025-01-31','2025-03-02',1550,125.55,1675.55,'PAYEE','2025-02-28'),
(1,5,'FAC-2025-021','2025-02-28','2025-03-30',20000,1620,21620,'EN_ATTENTE',NULL),
(2,NULL,'FAC-2025-022','2025-02-28','2025-03-30',8166.67,661.50,8828.17,'PAYEE','2025-03-25'),
(3,4,'FAC-2025-023','2025-02-28','2025-03-30',2900,234.90,3134.90,'EN_ATTENTE',NULL),
(1,NULL,'FAC-2025-024','2025-01-10','2025-02-09',28000,2268,30268,'EN_RETARD',NULL);

-- ── VUES UTILES ───────────────────────────────────────────
CREATE VIEW dbo.v_TicketsOuverts AS
SELECT t.TicketID, c.RaisonSociale, t.Titre, t.Priorite, t.Statut,
       t.DateOuverture, e.Prenom + ' ' + e.Nom AS Technicien, t.Categorie
FROM dbo.Tickets t
JOIN dbo.Clients c ON t.ClientID = c.ClientID
JOIN dbo.Employes e ON t.TechnicienID = e.EmployeID
WHERE t.Statut IN ('OUVERT','EN_COURS');

CREATE VIEW dbo.v_FacturesEnAttente AS
SELECT f.NumeroFacture, c.RaisonSociale, f.DateFacture,
       f.DateEcheance, f.MontantTTC, f.Statut,
       DATEDIFF(DAY, f.DateEcheance, GETDATE()) AS JoursRetard
FROM dbo.Factures f
JOIN dbo.Clients c ON f.ClientID = c.ClientID
WHERE f.Statut IN ('EN_ATTENTE','EN_RETARD')
ORDER BY f.DateEcheance;

CREATE VIEW dbo.v_ChiffreAffairesMensuel AS
SELECT YEAR(DateFacture) AS Annee, MONTH(DateFacture) AS Mois,
       COUNT(*) AS NbFactures,
       SUM(MontantHT) AS TotalHT, SUM(MontantTTC) AS TotalTTC,
       SUM(CASE WHEN Statut='PAYEE' THEN MontantTTC ELSE 0 END) AS Encaisse
FROM dbo.Factures
GROUP BY YEAR(DateFacture), MONTH(DateFacture);

PRINT 'Base axonix_db creee avec succes - 4 tables, 3 vues, donnees inserees.';
